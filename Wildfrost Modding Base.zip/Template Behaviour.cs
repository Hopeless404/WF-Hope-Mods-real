﻿using Deadpan.Enums.Engine.Components.Modding;
using FMODUnity;
using HarmonyLib;
using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace WildfrostHopeMod.$safeprojectname$
{
    public class $safeprojectname$ModBehaviour : MonoBehaviour
    {
        internal void Start()
        {
        }

        void Update()
        {
            if (Input.GetKey(KeyCode.LeftAlt))
            {
            }

            if (Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.T))
            {
            }
        }
    }
}